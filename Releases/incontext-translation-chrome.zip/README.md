# Lingoport InContext Translation
Lingoport Incontext Translation is a WebExtension compatible with Chrome that helps you to send a web page to a Lingoport InContext Server.


## Install
 - Chrome Web Store:


## Getting started
- 


## Code derived from third party projects
- csstree: https://github.com/csstree/csstree
- postcss-media-query-parser: https://github.com/dryoma/postcss-media-query-parser
- UglifyCSS: https://github.com/fmarcia/UglifyCSS
- parse-srcset: https://github.com/albell/parse-srcset
- parse-css-font: https://github.com/jedmao/parse-css-font

## License
